/**
 * Plugin designed for test prupose. It add a button (that manage an alert) and a select (that allow to insert tags) in the toolbar.
 * This plugin also disable the "f" key in the editarea, and load a CSS and a JS file
 */  
var EditArea_html= {
	/**
	 * Get called once this file is loaded (editArea still not initialized)
	 *
	 * @return nothing	 
	 */	 	 	
	init: function(){	
//			alert("html init: "+ this._someInternalFunction(2, 3));
//		editArea.load_css(this.baseURL+"css/test.css");
	}
	/**
	 * Returns the HTML code for a specific control string or false if this plugin doesn't have that control.
	 * A control can be a button, select list or any other HTML item to present in the EditArea user interface.
	 * Language variables such as {$lang_somekey} will also be replaced with contents from
	 * the language packs.
	 * 
	 * @param {string} ctrl_name: the name of the control to add	  
	 * @return HTML code for a specific control or false.
	 * @type string	or boolean
	 */	
	,get_control_html: function(ctrl_name){
		switch(ctrl_name){
			case "html":
				html=parent.editAreaLoader.get_button_html('html_h3', 'h3.gif', 'html_h3', false, this.baseURL);
				html+=parent.editAreaLoader.get_button_html('html_h4', 'h4.gif', 'html_h4', false, this.baseURL);
				html+=parent.editAreaLoader.get_button_html('html_p', 'p.gif', 'html_p', false, this.baseURL);
				html+=parent.editAreaLoader.get_button_html('html_b', 'b.gif', 'html_b', false, this.baseURL);
				html+=parent.editAreaLoader.get_button_html('html_a', 'a.gif', 'html_a', false, this.baseURL);
				html+=parent.editAreaLoader.get_button_html('html_img', 'img.gif', 'html_img', false, this.baseURL);
				html+=parent.editAreaLoader.get_button_html('html_center', 'center.gif', 'html_center', false, this.baseURL);
				html+=parent.editAreaLoader.get_button_html('html_pagebreak','pagebreak.gif','html_pagebreak',false,this.baseURL);
				return html;

		}
		return false;
	}
	/**
	 * Get called once EditArea is fully loaded and initialised
	 *	 
	 * @return nothing
	 */	 	 	
	,onload: function(){ 
//		alert("test load");
	}
	
	/**
	 * Is called each time the user touch a keyboard key.
	 *	 
	 * @param (event) e: the keydown event
	 * @return true - pass to next handler in chain, false - stop chain execution
	 * @type boolean	 
	 */
	,onkeydown: function(e){
		switch(e.keyCode){
			case 13://enter
				if(e.shiftKey==1){
					parent.editAreaLoader.insertTags(editArea.id, "<br/>\n", "");
					return false;
				}else if(e.ctrlKey==1){
					parent.editAreaLoader.insertTags(editArea.id, "\n<p>", "</p>");
					return false;
				}

/*			case 66://b
				if(e.ctrlKey==1){
					parent.editAreaLoader.insertTags(editArea.id, "<strong>", "</strong>");
				}
*/
			
		}
	}
	
	/**
	 * Executes a specific command, this function handles plugin commands.
	 *
	 * @param {string} cmd: the name of the command being executed
	 * @param {unknown} param: the parameter of the command	 
	 * @return true - pass to next handler in chain, false - stop chain execution
	 * @type boolean	
	 */
	,execCommand: function(cmd, param){
		// Handle commands
		switch(cmd){
			case "html_a":
				parent.editAreaLoader.insertTags(editArea.id, "<a href=\"\" title=\"\">", "</a>");
				return false;
			case "html_p":
				parent.editAreaLoader.insertTags(editArea.id, "<p>", "</p>");
				return false;
			case "html_h3":
				parent.editAreaLoader.insertTags(editArea.id, "<h3>", "</h3>");
				return false;
			case "html_h4":
				parent.editAreaLoader.insertTags(editArea.id, "<h4>", "</h4>");
				return false;
			case "html_img":
				parent.editAreaLoader.insertTags(editArea.id, "<img src=\"", "\" alt=\"\" />");
				return false;
			case "html_b":
				parent.editAreaLoader.insertTags(editArea.id, "<strong>", "</strong>");
				return false;
			case "html_center":
				parent.editAreaLoader.insertTags(editArea.id, "<p class=\"c\">", "</p>");
				return false;
			case "html_pagebreak":
				parent.editAreaLoader.insertTags(editArea.id, "\n<!-- pagebreak -->\n", "");
				return false;



		}
		/*
		*/
		// Pass to next handler in chain
		return true;
	}
	
	/**
	 * This is just an internal plugin method, prefix all internal methods with a _ character.
	 * The prefix is needed so they doesn't collide with future EditArea callback functions.
	 *
	 * @param {string} a Some arg1.
	 * @param {string} b Some arg2.
	 * @return Some return.
	 * @type unknown
	 */
	,_someInternalFunction : function(a, b) {
		return a+b;
	}
};

// Adds the plugin class to the list of available EditArea plugins
editArea.add_plugin("html", EditArea_html);
