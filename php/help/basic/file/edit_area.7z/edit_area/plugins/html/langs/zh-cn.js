editArea.add_lang("zh-cn",{
html_a: "链接",
html_p: "段落",
html_img: "插入图片",
html_b:"加粗",
html_center:"居中",
html_h3:"标题3",
html_h4:"标题4",
html_pagebreak:"插入分页代码",
});
